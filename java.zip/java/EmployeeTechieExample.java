class Employee {
    int eId;
    String eName;
    String desg;
    final String company_name = "Tech Solutions";

    public Employee(int eId, String eName, String desg) {
        this.eId = eId;
        this.eName = eName;
        this.desg = desg;
    }

    public void displayDetails() {
        System.out.println("Employee ID: " + eId);
        System.out.println("Employee Name: " + eName);
        System.out.println("Designation: " + desg);
        System.out.println("Company Name: " + company_name);
    }
}

class Techie extends Employee {
    final String department = "Technology";

    public Techie(int eId, String eName, String desg) {
        super(eId, eName, desg);
    }

    public void calculate_salary(double bonus) {
        double baseSalary = 50000; // Example base salary
        double totalSalary = baseSalary + bonus;
        System.out.println("Total Salary with Bonus: " + totalSalary);
    }

    public void displayDetails() {
        super.displayDetails();
        System.out.println("Department: " + department);
    }
}

public class EmployeeTechieExample {
    public static void main(String[] args) {
        Techie techie = new Techie(101, "Alice", "Software Engineer");
        techie.displayDetails();
        techie.calculate_salary(5000);
    }
}