class Vehicle {
    public void move() {
        System.out.println("The vehicle is moving.");
    }
}

class Car extends Vehicle {
    public void horn() {
        System.out.println("The car is honking.");
    }
}

public class VehicleCarInheritance {
    public static void main(String[] args) {
        Car myCar = new Car();
        myCar.move();
        myCar.horn();
    }
}