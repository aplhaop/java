package main;

import data.DataInput;
import operations.Addition;
import operations.Subtraction;

public class Main {
    public static void main(String[] args) {
        int[] numbers = DataInput.acceptData();
        int sum = Addition.add(numbers[0], numbers[1]);
        int difference = Subtraction.subtract(numbers[0], numbers[1]);

        System.out.println("Sum: " + sum);
        System.out.println("Difference: " + difference);
    }
}
