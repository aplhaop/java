import java.util.Scanner;

abstract class Shape {
    int dimension1;
    int dimension2;

    public Shape(int dimension1, int dimension2) {
        this.dimension1 = dimension1;
        this.dimension2 = dimension2;
    }

    abstract void calculateArea();
    abstract void calculateCircumference();
}

class Rectangle extends Shape {
    public Rectangle(int length, int width) {
        super(length, width);
    }

    @Override
    void calculateArea() {
        int area = dimension1 * dimension2;
        System.out.println("Area of Rectangle: " + area);
    }

    @Override
    void calculateCircumference() {
        int circumference = 2 * (dimension1 + dimension2);
        System.out.println("Circumference of Rectangle: " + circumference);
    }
}

class Triangle extends Shape {
    public Triangle(int base, int height) {
        super(base, height);
    }

    @Override
    void calculateArea() {
        double area = 0.5 * dimension1 * dimension2;
        System.out.println("Area of Triangle: " + area);
    }

    @Override
    void calculateCircumference() {
        System.out.println("Circumference of Triangle: Not calculated (requires all three sides)");
    }
}

class Circle extends Shape {
    public Circle(int radius) {
        super(radius, 0);
    }

    @Override
    void calculateArea() {
        double area = Math.PI * dimension1 * dimension1;
        System.out.println("Area of Circle: " + area);
    }

    @Override
    void calculateCircumference() {
        double circumference = 2 * Math.PI * dimension1;
        System.out.println("Circumference of Circle: " + circumference);
    }
}

public class AbstractShapeExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter length and width of Rectangle: ");
        Rectangle rectangle = new Rectangle(scanner.nextInt(), scanner.nextInt());
        rectangle.calculateArea();
        rectangle.calculateCircumference();

        System.out.print("Enter base and height of Triangle: ");
        Triangle triangle = new Triangle(scanner.nextInt(), scanner.nextInt());
        triangle.calculateArea();
        triangle.calculateCircumference();

        System.out.print("Enter radius of Circle: ");
        Circle circle = new Circle(scanner.nextInt());
        circle.calculateArea();
        circle.calculateCircumference();
    }
}