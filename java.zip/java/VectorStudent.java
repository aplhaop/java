import java.util.Vector;
import java.util.Scanner;

public class VectorStudent {
    private Vector<String> studentNames;

    public VectorStudent() {
        studentNames = new Vector<>();
    }

    public void addStudent(String name) {
        studentNames.add(name);
    }

    public void addStudentAtIndex(int index, String name) {
        if (index >= 0 && index <= studentNames.size()) {
            studentNames.add(index, name);
        } else {
            System.out.println("Invalid index.");
        }
    }

    public void removeStudent(String name) {
        if (studentNames.remove(name)) {
            System.out.println(name + " removed from the list.");
        } else {
            System.out.println(name + " not found in the list.");
        }
    }

    public void removeAllStudents() {
        studentNames.clear();
        System.out.println("All students removed from the list.");
    }

    public void displaySizeAndCapacity() {
        System.out.println("Size of the vector: " + studentNames.size());
        System.out.println("Capacity of the vector: " + studentNames.capacity());
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        VectorStudent vs = new VectorStudent();

        while (true) {
            System.out.println("\n1. Add Student");
            System.out.println("2. Add Student at Index");
            System.out.println("3. Remove Student");
            System.out.println("4. Remove All Students");
            System.out.println("5. Display Size and Capacity");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter student name: ");
                    String name = scanner.nextLine();
                    vs.addStudent(name);
                    break;
                case 2:
                    System.out.print("Enter index: ");
                    int index = scanner.nextInt();
                    System.out.print("Enter student name: ");
                    String studentNameAtIndex = scanner.next();
                    vs.addStudentAtIndex(index, studentNameAtIndex);
                    break;
                case 3:
                    System.out.print("Enter student name to remove: ");
                    String removeName = scanner.nextLine();
                    vs.removeStudent(removeName);
                    break;
                case 4:
                    vs.removeAllStudents();
                    break;
                case 5:
                    vs.displaySizeAndCapacity();
                    break;
                case 6:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}