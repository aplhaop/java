import java.util.Scanner;

public class CopyArray {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the number of elements in the array: ");
        int n = scanner.nextInt();
        int[] sourceArray = new int[n];
        int[] destinationArray = new int[n];

        System.out.println("Enter the elements of the source array:");
        for (int i = 0; i < n; i++) {
            sourceArray[i] = scanner.nextInt();
        }

        copyArray(sourceArray, destinationArray);

        System.out.println("Elements copied to the destination array:");
        for (int element : destinationArray) {
            System.out.print(element + " ");
        }
        
        scanner.close();
    }

    public static void copyArray(int[] source, int[] destination) {
        for (int i = 0; i < source.length; i++) {
            destination[i] = source[i];
        }
    }
}