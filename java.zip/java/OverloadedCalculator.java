import java.util.Scanner;

class Calculator {
    public int multiply(int a, int b) {
        return a * b;
    }

    public int multiply(int a, int b, int c) {
        return a * b * c;
    }

    public double multiply(double a, double b) {
        return a * b;
    }
}

public class OverloadedCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Calculator calculator = new Calculator();

        System.out.print("Enter first integer: ");
        int firstInt = scanner.nextInt();
        System.out.print("Enter second integer: ");
        int secondInt = scanner.nextInt();
        System.out.println("Product of two integers: " + calculator.multiply(firstInt, secondInt));

        System.out.print("Enter third integer: ");
        int thirdInt = scanner.nextInt();
        System.out.println("Product of three integers: " + calculator.multiply(firstInt, secondInt, thirdInt));

        System.out.print("Enter first double: ");
        double firstDouble = scanner.nextDouble();
        System.out.print("Enter second double: ");
        double secondDouble = scanner.nextDouble();
        System.out.println("Product of two doubles: " + calculator.multiply(firstDouble, secondDouble));

        scanner.close();
    }
}
