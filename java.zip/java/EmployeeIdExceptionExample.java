class InvalidEmployeeIdException extends Exception {
    public InvalidEmployeeIdException(String message) {
        super(message);
    }
}

class Employee {
    int eId;

    public Employee(int eId) throws InvalidEmployeeIdException {
        if (eId <= 0) {
            throw new InvalidEmployeeIdException("Invalid Employee ID: " + eId);
        }
        this.eId = eId;
    }

    public void displayEmployeeId() {
        System.out.println("Employee ID: " + eId);
    }
}

public class EmployeeIdExceptionExample {
    public static void main(String[] args) {
        try {
            Employee employee = new Employee(-1);
            employee.displayEmployeeId();
        } catch (InvalidEmployeeIdException e) {
            System.out.println(e.getMessage());
        }
        
        try {
            Employee employee = new Employee(101);
            employee.displayEmployeeId();
        } catch (InvalidEmployeeIdException e) {
            System.out.println(e.getMessage());
        }
    }
}