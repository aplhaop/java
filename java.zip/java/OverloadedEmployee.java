class Employee {
    private String name;
    private int age;
    private String department;

    public Employee(String name) {
        this.name = name;
        this.age = 0;
        this.department = "Not specified";
    }

    public Employee(String name, int age) {
        this.name = name;
        this.age = age;
        this.department = "Not specified";
    }

    public Employee(String name, String department) {
        this.name = name;
        this.age = 0;
        this.department = department;
    }

    public Employee(String name, int age, String department) {
        this.name = name;
        this.age = age;
        this.department = department;
    }

    public void displayDetails() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Department: " + department);
    }
}

public class OverloadedEmployee {
    public static void main(String[] args) {
        Employee employee1 = new Employee("Alice");
        Employee employee2 = new Employee("Bob", 30);
        Employee employee3 = new Employee("Charlie", "Finance");
        Employee employee4 = new Employee("David", 25, "Engineering");

        System.out.println("Employee 1 Details:");
        employee1.displayDetails();
        System.out.println();

        System.out.println("Employee 2 Details:");
        employee2.displayDetails();
        System.out.println();

        System.out.println("Employee 3 Details:");
        employee3.displayDetails();
        System.out.println();

        System.out.println("Employee 4 Details:");
        employee4.displayDetails();
    }
}