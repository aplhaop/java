import java.util.Scanner;

class Employee {
    private String name;
    private int id;
    private String department;
    private double salary;

    public void setName(String name) {
        this.name = name;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void displayDetails() {
        System.out.println("Employee ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Department: " + department);
        System.out.println("Salary: " + salary);
    }
}

public class EmployeeDetails {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter number of employees: ");
        int numberOfEmployees = scanner.nextInt();
        scanner.nextLine(); 

        Employee[] employees = new Employee[numberOfEmployees];

        for (int i = 0; i < numberOfEmployees; i++) {
            employees[i] = new Employee();
            System.out.print("Enter name of employee " + (i + 1) + ": ");
            employees[i].setName(scanner.nextLine());
            System.out.print("Enter ID of employee " + (i + 1) + ": ");
            employees[i].setId(scanner.nextInt());
            scanner.nextLine(); 
            System.out.print("Enter department of employee " + (i + 1) + ": ");
            employees[i].setDepartment(scanner.nextLine());
            System.out.print("Enter salary of employee " + (i + 1) + ": ");
            employees[i].setSalary(scanner.nextDouble());
            scanner.nextLine(); 
            System.out.println();
        }

        System.out.println("Employee Details:");
        for (Employee employee : employees) {
            employee.displayDetails();
            System.out.println();
        }

        scanner.close();
    }
}