package operations;

public class Subtraction {
    public static int subtract(int num1, int num2) {
        return num1 - num2;
    }
}