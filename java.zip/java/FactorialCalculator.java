import java.util.Scanner;

public class FactorialCalculator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a positive integer to calculate its factorial: ");
        
        int number = scanner.nextInt();
        long factorial = 1;
        
        if (number < 0) {
            System.out.println("Factorial is not defined for negative numbers.");
        } else {
            int i = 1;
            do {
                factorial *= i;
                i++;
            } while (i <= number);
            
            System.out.println("Factorial of " + number + " is: " + factorial);
        }
        
        scanner.close();
    }
}