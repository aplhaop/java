import java.util.Scanner;

public class StringLength {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter a string: ");
        String inputString = scanner.nextLine();

        int lengthUsingInbuilt = inputString.length();
        int lengthUsingUserDefined = calculateLength(inputString);

        System.out.println("Length using inbuilt method: " + lengthUsingInbuilt);
        System.out.println("Length using user-defined method: " + lengthUsingUserDefined);
        
        scanner.close();
    }

    public static int calculateLength(String str) {
        int length = 0;
        for (char c : str.toCharArray()) {
            length++;
        }
        return length;
    }
}