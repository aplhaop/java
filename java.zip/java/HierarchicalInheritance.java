class Shape {
    public void draw() {
        System.out.println("Drawing a shape.");
    }
}

class Circle extends Shape {
    public void draw() {
        super.draw();
        System.out.println("Drawing a circle.");
    }

    public void displayCircleInfo() {
        System.out.println("This is a circle.");
    }
}

class Rectangle extends Shape {
    public void draw() {
        super.draw();
        System.out.println("Drawing a rectangle.");
    }

    public void displayRectangleInfo() {
        System.out.println("This is a rectangle.");
    }
}

public class HierarchicalInheritance {
    public static void main(String[] args) {
        Circle circle = new Circle();
        circle.draw();
        circle.displayCircleInfo();

        Rectangle rectangle = new Rectangle();
        rectangle.draw();
        rectangle.displayRectangleInfo();
    }
}