import java.util.ArrayList;
import java.util.Scanner;

class Book {
    private String title;
    private String author;
    private double price;

    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public double getPrice() {
        return price;
    }

    public void displayDetails() {
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("Price: " + price);
    }
}

public class BookDetails {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Book> books = new ArrayList<>();
        int numberOfBooks;

        System.out.print("Enter the number of books: ");
        numberOfBooks = scanner.nextInt();
        scanner.nextLine();

        for (int i = 0; i < numberOfBooks; i++) {
            Book book = new Book();
            System.out.print("Enter title of book " + (i + 1) + ": ");
            book.setTitle(scanner.nextLine());
            System.out.print("Enter author of book " + (i + 1) + ": ");
            book.setAuthor(scanner.nextLine());
            System.out.print("Enter price of book " + (i + 1) + ": ");
            book.setPrice(scanner.nextDouble());
            scanner.nextLine();
            books.add(book);
        }

        System.out.println("Book Details:");
        for (Book book : books) {
            book.displayDetails();
            System.out.println();
        }
        
        scanner.close();
    }
}