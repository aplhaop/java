import java.util.Scanner;

class Rectangle {
    private double length;
    private double breadth;

    public Rectangle() {
        length = 1.0;
        breadth = 1.0;
    }

    public Rectangle(double length, double breadth) {
        this.length = length;
        this.breadth = breadth;
    }

    public double calculateArea() {
        return length * breadth;
    }
}

public class RectangleArea {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter length of the rectangle: ");
        double length = scanner.nextDouble();
        
        System.out.print("Enter breadth of the rectangle: ");
        double breadth = scanner.nextDouble();
        
        Rectangle userDefinedRectangle = new Rectangle(length, breadth);
        
        System.out.println("Area of the rectangle: " + userDefinedRectangle.calculateArea());
        
        scanner.close();
    }
}