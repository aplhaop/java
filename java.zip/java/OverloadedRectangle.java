class Rectangle {
    private double length;
    private double width;

    public Rectangle() {
        length = 1.0;
        width = 1.0;
    }

    public Rectangle(double length, double width) {
        this.length = length;
        this.width = width;
    }

    public Rectangle(double side) {
        length = side;
        width = side;
    }

    public double calculateArea() {
        return length * width;
    }
}

public class OverloadedRectangle {
    public static void main(String[] args) {
        Rectangle rectangle1 = new Rectangle();
        Rectangle rectangle2 = new Rectangle(5.0, 3.0);
        Rectangle square = new Rectangle(4.0);

        System.out.println("Area of default rectangle: " + rectangle1.calculateArea());
        System.out.println("Area of rectangle with length 5.0 and width 3.0: " + rectangle2.calculateArea());
        System.out.println("Area of square with side 4.0: " + square.calculateArea());
    }
}