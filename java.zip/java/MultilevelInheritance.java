class Person {
    public void display() {
        System.out.println("This is a person.");
    }
}

class Employee extends Person {
    public void display() {
        super.display();
        System.out.println("This is an employee.");
    }
}

class Manager extends Employee {
    public void display() {
        super.display();
        System.out.println("This is a manager.");
    }
}

public class MultilevelInheritance {
    public static void main(String[] args) {
        Manager manager = new Manager();
        manager.display();
    }
}